
package com.example;

public class InfiniteLoop {
    public static void main(String[] args) {
        int i;
   
    // The for loop will run infinite times.
    for(i = 1;i <= 5;i ++){
       System.out.println("Hello");
        
    }
     
    // To terminate this program press ctrl + c in the console.
  }
} 
    

