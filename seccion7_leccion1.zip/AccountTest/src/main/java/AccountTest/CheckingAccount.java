
package AccountTest;
/**
 *
 * @author jose
 */
public class CheckingAccount {
      public double balance = 1000.00;
       public String name = "Jesus";
        public double anterior;
        
    public void withdraw(double x){
            balance -= x;
            anterior = balance + x;
            if(x > balance){
                System.out.println("SALDO INSUFICIENTE");
                
            }
            if(0 > x){
                    System.out.println("POR FAVOR INGRESE UN NUMERO POSITIVO YA QUE EL QUE HA INGRESADO ES NEGATIVO");
                }
            else{
              System.out.println("saldo anterior: " + anterior);
              System.out.println("usted ha retirado: "+ x);
              System.out.println("su saldo actual es: " + balance);
            }
        }
}
