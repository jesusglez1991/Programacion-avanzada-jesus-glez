package AccountTest;

/**
 *
 * @author jose
 */
public class AccountTest {
    public static void main(String[] args) {
       // CheckingAccount ca01 = new CheckingAccount();
        //ca01.withdraw(200.00);
       bonos bo01 = new bonos();
        bo01.plInt(2);
        bo01.ganInt();
        
        
      
    }
    
   
}