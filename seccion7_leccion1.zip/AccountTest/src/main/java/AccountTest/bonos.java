/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccountTest;

/**
 *
 * @author jose
 */
public class bonos {

    public int plazo, mesesrest;
    public double interes;
    public double balanceb = 1000.00;
    public String nombre;
    
    public void plInt(int t){
        if (t >= 0 && t < 12)
        interes = 0.005;
        else if(t >= 12 && t < 24)
        interes = 0.010;
        else if(t >= 24 && t < 36)
        interes = 0.015;
        else if(t >= 36 && t < 48)
        interes = 0.020;
        else if(t >= 48 && t < 60)
        interes = 0.025;
        else{
            System.out.println("plazo invalido");
            t = 0;
        }
        plazo = t;
        mesesrest = t;
    }
    
    public void ganInt(){
        if (mesesrest > 0){
            balanceb += balanceb * interes / 12;
            mesesrest --;
            System.out.println("Su Balance: $ " + balanceb);
            System.out.println("valor del interes: " + interes);
            System.out.println("meses restantes en el plazo: " + mesesrest +" meses.");
        }
        else{
            System.out.println("Plazo vencido");
        }
    }
}
