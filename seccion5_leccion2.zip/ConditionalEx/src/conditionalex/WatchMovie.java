/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditionalex;

import java.util.Scanner;

/**
 *
 * @author anshenoy
 */
public class WatchMovie {

    public static void main(String args[]) {
        int precio , cla; 
       
       System.out.print("Enter the movie ticket price \n");
        Scanner price = new Scanner(System.in);
        precio = price.nextInt();
        System.out.println("ingrese la clasificacion de la pelicula: ");
        Scanner clas = new Scanner(System.in);
        cla = clas.nextInt();
       
        if(precio >= 12 && cla == 5){
            System.out.println("si deseo ver la pelicula");
        }
           else
        {
            System.out.println("no ,no deseo ver la pelicula");
        }

    }
}
