package parsing01;

public class Parsing01 {
    public static void main(String[] args) {
        //Declare and intitialize 3 Strings: shirtPrice, taxRate, and gibberish
       String shirtPrice = "100";
       String taxRate = "2.50";
        String gibberish = "887ds7nds87dsfs";
        
        
        
        //Parse shirtPrice and taxRate, and print the total tax
        int vara = Integer.parseInt(shirtPrice);
        double varb = Double.parseDouble(taxRate);
        System.out.println(vara * varb);
        
        //Try to parse taxRate as an int
        int varc =Integer.parseInt(taxRate);
        //Try to parse gibberish as an int
        int vad = Integer.parseInt(gibberish);
    }
    
}
