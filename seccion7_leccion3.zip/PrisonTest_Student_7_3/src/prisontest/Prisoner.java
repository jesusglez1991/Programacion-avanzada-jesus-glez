package prisontest;

public class Prisoner {
    //Fields 
    public String name;
    public double height;
    public int sentence;
    
    /* public void setFields(String n, double h, int s){
name = n;
height = h;
sentence = s;
     }*/
    //Constructor
   
    public Prisoner(String n, double h, int s){
name = n;
height = h;
sentence = s;
    System.out.println(n + ", " + h + ", " + s);
    //Methods
    //public void think(){
        //System.out.println("I'll have my revenge.");
    }   

    Prisoner() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
