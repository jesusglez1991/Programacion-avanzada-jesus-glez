package prisontest;

public class PrisonTest {
    public static void main(String[] args){
        Prisoner pr1 = new Prisoner();
        Prisoner pr2 = new Prisoner();
            //Prisoner  pris = new Prisoner();
        /*String name = pris.name;
        double height = pris.height;
        int sentence = pris.sentence;
        System.out.println(name +" " + height +" " + sentence);*/
       //pr1.setFields("bubba", 1.90, 10);
       //pr2.setFields("Twitch", 1.73, 3);
        pr1.name = "Bubba";
pr1.height = 2.08;
pr1.sentence = 4;
pr2.name = "Twitch";
pr2.height = 1.73;
pr2.sentence = 3;
        
    } 
}
