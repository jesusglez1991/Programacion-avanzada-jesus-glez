
package chickens02;

public class Chickens02 {
    public static void main(String[] args) {
        //Put yout code here
  double lunes = 100; double martes = 121; double miercoles = 117; 
//dailyAverage
double dailyAverage =(lunes + martes + miercoles)/3;
//monthlyAverage
double monthlyAverage = dailyAverage * 30;
//monthlyProfit
double monthlyProfit = monthlyAverage *.18;
        System.out.println("Daily Average:   " +dailyAverage);
        System.out.println("Monthly Average: " +monthlyAverage);
        System.out.println("Monthly Profit:  $" +monthlyProfit);
    }
    
}
