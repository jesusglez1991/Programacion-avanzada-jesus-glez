
package com.example;

import java.util.*;


public class SquareRootWhile {
    public static void main(String args[])
    {
        
    System.out.print("Type a non-negative integer: ");
     Scanner console = new Scanner(System.in);
	int number = console.nextInt();
while(number != -1){
    double resultado = Math.sqrt(number);
    System.out.println("el resultado de la raiz cuadrada es: " + resultado);
    number = console.nextInt();
}
        System.out.println("numero invalido intente de nuevo");	
    
}
    
}
