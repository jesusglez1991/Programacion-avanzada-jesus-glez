
package shoppingcart02;

public class ShoppingCart02 {
    public static void main(String[] args) {
          String custName = "Alex ";
        String itemDesc = " Shirts";
        //String message = custName+" wants to purchase  " +itemDesc;
        
        // Declare and initialize numeric fields: price, tax, quantity.   
        //price
        double price = 2.50;
        //tax
        double tax = price * .15;
        //quantity
        int quantity = 2;
        
        
        // Declare and assign a calculated totalPrice
        double total = (price + tax)* quantity;        
        // Modify message to include quantity 
        
        System.out.println(custName + "wants to purchase " + quantity + itemDesc);
        
        // Print another message with the total cost
        System.out.println(total);
        
    }    
}
