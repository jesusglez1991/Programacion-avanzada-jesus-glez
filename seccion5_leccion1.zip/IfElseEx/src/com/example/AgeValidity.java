/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import java.util.Scanner;

/**
 *
 * @author anshenoy
 */
public class AgeValidity {

    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
        int edad;
        
        System.out.println("por favor introduzca su edad: ");
         edad = sc.nextInt();
       boolean drivingUnderAge;
       drivingUnderAge = false;
       drivingUnderAge = edad <= 18;
        System.out.println(drivingUnderAge);
       
    }
}
