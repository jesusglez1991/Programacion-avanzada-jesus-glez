/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */

import java.util.Scanner;
public class StringEquality {
  public static void main(String[] args) {
       String nombre , a = "moe";
      
         
   Scanner sc = new Scanner(System.in);
System.out.println("por favor introduzca su nombre: ");
        nombre = sc.nextLine();
        boolean test;
        test = false;
        test = a.equals(nombre);
        if (a.equals(nombre)){
            System.out.println("TU ERES EL REY DEL ROCK AND ROLL!!!!");
        }
        else {
            System.out.println("....tu no eres el rey u.u");
        }
    }
}
    


