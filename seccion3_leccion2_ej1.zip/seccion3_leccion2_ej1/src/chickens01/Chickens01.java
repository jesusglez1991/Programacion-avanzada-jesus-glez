
package chickens01;

public class Chickens01 {
    public static void main(String[] args) {
        //Put yout code here
int eggsPerChicken = 5;  int chickenCount = 3; 
int eggsPerChicken2 = 4;  int chickenCount2 = 8;
//lunes
int lunes = eggsPerChicken * (chickenCount);
int lunes2 = eggsPerChicken2 * (chickenCount2);
//martes
int martes = eggsPerChicken * (chickenCount + 1);
int martes2 = eggsPerChicken2 * (chickenCount2 + 1);
//miercoles
int miercoles = eggsPerChicken * ((chickenCount +1)/2);
int miercoles2 = eggsPerChicken2 * ((chickenCount2 +1)/2);
//dailyAverage
int totalEggs = lunes + martes + miercoles;
int totalEggs2 = lunes2 + martes2 + miercoles2;
        System.out.println("caso 1 totalEggs: " + totalEggs);
        System.out.println("caso 2 totaleggs: " + totalEggs2);
    
    }  
    
}
