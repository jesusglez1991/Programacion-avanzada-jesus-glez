package input03;
import java.util.Scanner;
class Input03 {

    public static void main(String[] args) {
        System.out.println("ingrese tres numeros por favor");        
//Create a Scanner
        Scanner sc = new Scanner(System.in);
        //Find and print the sum of three integers entered by the user
        int vara = sc.nextInt();
        int varb = sc.nextInt();
        int varc = sc.nextInt();
        sc.close();
        int total= vara + varb + varc;
        System.out.println("el resultado de la suma es: " + total);
        //Remember to close the Scanner
        
    }
}
