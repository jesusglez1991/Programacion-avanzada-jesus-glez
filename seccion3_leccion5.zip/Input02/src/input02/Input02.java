package input02;

import javax.swing.JOptionPane;

public class Input02 {
    public static void main(String[] args) {
        
        JOptionPane.showMessageDialog(null,
                "Probando el cuadro de texto",
                "Prueba",
                3);

        
        String input1 = (String)JOptionPane.showInputDialog(null,
                "Hay que preguntar?",
                "ayudaaa",
                2,
                null,
                null,
                "Escriba algo aqui:");
        
        
        String[] acceptableValues = {"opcion 1", "opcion 2", "opcion 3"};
        String input2 = (String)JOptionPane.showInputDialog(null,
                "es una pregunta?",
                "opciones(la 1)",
                1,
                null,
                acceptableValues,
                acceptableValues[1]);
                
    }
}
