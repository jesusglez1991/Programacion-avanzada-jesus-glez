package input01;

import javax.swing.JOptionPane;

public class Input01 {
    public static void main(String[] args) {
        //Create a JOptionPane.
        //Store the input as a String and print it.
       String inputstring = JOptionPane.showInputDialog("ingrese un numero por favor:");
         
       System.out.println("variable ingresada: " + inputstring);
        
        //Parse the input as an int.
        //Print its value +1
        int input = Integer.parseInt(inputstring);
        int adicion = input +1;
        System.out.println("variable ingresada +1: " + adicion);
        
        //Try creating a dialog, parsing it, and initializing an int in a single line.
        //You should have only one semicolon (;) in this line.

        int entrada = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero por favor: "))+1;
        System.out.println("variable ingresada: " + entrada);
    }
}
