package HistoriaParcipativa;

import javax.swing.JOptionPane;

/**
 *
 * @author jose
 */
public class historia {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,
                "muy buenas tardes en este programa crearemos una historia similar\n a la prueba psicologica de los psiquiatras pero sin la parte del analisis",
                "Hagamos una historia",
                1);

        JOptionPane.showMessageDialog(null,
                "Continuemos entonces",
                "Hagamos una historia",
                1);

        String nombre = JOptionPane.showInputDialog("ingrese su nombre por favor: ");
        String pais = JOptionPane.showInputDialog("Ingrese el nombre del pais donde recide: ");
        String artista = JOptionPane.showInputDialog("Ingrese el nombre de su artista favorito: ");

        JOptionPane.showMessageDialog(null,
                "Mi nombre es " + nombre + " y vivo en "
                + pais + " y esta es una pequeña historia de como conoci  a\n" + artista
                + "Todo empezo un dia mientras caminaba por la calle y pude ver un letrero donde se anunciaba la visita de\n" + artista
                + " quien siempre ha sido mi inspiracion y me emocionaba esta oportunidad\n asi que me dirigi a comprar las entradas para el evento\n"
                + " pero no esperaba lo que estaba por pasarme.\n Mientras me dirigia a la taquilla tropece con alguien que no distingui\n"
                + " con el impacto fui a dar al piso y solo pude escuchar una voz disculpandose\n no lo podia creer era " + artista
                + " con quien habia tropezado quien me ayudo a levantarme\n y como disculpa me regalo voletos y se tomo una foto conmigo la cual autografio.",
                "Su historia",
                1);
         JOptionPane.showMessageDialog(null,
                "Gracias por su participacion",
                "Hagamos una historia",
                1);

    }
}
