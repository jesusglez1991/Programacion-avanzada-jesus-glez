
package shoppingcart01;

public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
        String custName , itemDesc , message;
        
        
        
        // Assign the message variable 
        custName = "Alex ";
        itemDesc = "quiere una playera";
        message = custName + itemDesc;
        // Print and run the code
        System.out.println(message);
    }
}
